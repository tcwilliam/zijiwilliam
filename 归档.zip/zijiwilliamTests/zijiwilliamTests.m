//
//  zijiwilliamTests.m
//  zijiwilliamTests
//
//  Created by 文力 王 on 13-3-10.
//  Copyright (c) 2013年 文力 王. All rights reserved.
//

#import "zijiwilliamTests.h"

@implementation zijiwilliamTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in zijiwilliamTests");
}

@end
