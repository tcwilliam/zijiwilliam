//
//  zijiwilliamTests.h
//  zijiwilliamTests
//
//  Created by 文力 王 on 13-3-10.
//  Copyright (c) 2013年 文力 王. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface zijiwilliamTests : SenTestCase

@end
